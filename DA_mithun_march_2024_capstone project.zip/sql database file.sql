select * from merged_data
